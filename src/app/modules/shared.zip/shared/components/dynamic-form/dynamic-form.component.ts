import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
// import formJson from '../../../../core/data/user.json';
@Component({
  // selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',

  styleUrls: ['./dynamic-form.component.css']

})
export class DynamicFormComponent implements OnInit{
  constructor(private http: HttpClient) {}
  formData: any;

  ngOnInit(): void {
    this.fetchFormData();
  }
  fetchFormData(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      this.http.get<any>('/assets/user.json').subscribe(
        (data) => {
          this.formData = data;
          resolve();
        },
        (error) => {
          console.error('Failed to fetch form data:', error);
          reject();
        }
      );
    });
  }
  handleFormSubmitted(response: any) {
    // Handle the form submit response here
    console.log('Form submit response:', response);



// Retrieve existing form data from the local storage or initialize an empty array
let storedFormData = localStorage.getItem('formData');
let formDataArray = storedFormData ? JSON.parse(storedFormData) : [];

// Push the new form data object into the array
formDataArray.push(response);

// Convert the updated form data array to a JSON string
const updatedFormDataJson = JSON.stringify(formDataArray);

// Save the updated form data array in the local storage
localStorage.setItem('formData', updatedFormDataJson);

  // // Verify the updated JSON data
  console.log('Updated JSON data:', updatedFormDataJson);
  }

  
}
